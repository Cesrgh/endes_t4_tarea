import java.util.ArrayList;

/**
 * Clase Auto con información sobre un coche.
 * Esta clase contendrá información sobre objetos Auto, como son su marca y modelo.
 * @author César Ricardo González Hernández
 * @version 1.0, 05/03/2024
 */

public class Auto {

    /**
     * Marca del coche.
     */
    private String marca;

    /**
     * Modelo del coche.
     */
    private String modelo;

    /**
     * Constructor de la clase Auto.
     * @param marca Parametro que indica la marca del coche.
     * @param modelo Parametro que indica el modelo del coche.
     */
    public Auto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    /**
     * Método Get del parametro marca.
     * @return Devuelve la marca del coche.
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Método Set para el parametro marca, dandole un valor, en este caso una cadena de texto.
     * @param marca Marca del coche.
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Método Get del parametro modelo.
     * @return Devuelve el modelo del coche.
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Método Set para el parametro modelo, dandole un valor, en este caso una cadena de texto.
     * @param modelo Modelo del coche.
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Método que pasa el objeto Auto a String.
     * @return Devuelve un String describiendo un objeto Auto mediante su marca y modelo.
     */
    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + "]";
    }
}

