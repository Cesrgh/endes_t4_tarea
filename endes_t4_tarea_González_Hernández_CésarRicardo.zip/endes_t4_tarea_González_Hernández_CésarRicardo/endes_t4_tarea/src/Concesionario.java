/**
 * Importación de la ultilidad para poder usar ArrayLists.
 */

import java.util.ArrayList;

/**
 * Clase Concesionario para guardar los objetos Auto.
 * Se generará una lista de coches con los objetos generados con la clase Auto.
 * @author César Ricardo González Hernández.
 * @version 1.0 05/03/2024
 */
public class Concesionario {

    /**
     * Un Array list que contendrá objetos de la clase Auto
     */
    private ArrayList<Auto> autos;

    /**
     * Método que inicializa una nueva ArrayList
     */
    public Concesionario() {
        autos = new ArrayList<>();
    }

    /**
     * Método con el cual se añadiran objetos de la clase Auto a la ArrayList
     * @param auto Objeto de la clase Auto el cual contendrá marca y modelo del coche.
     */
    public void agregarAuto(Auto auto) {
        autos.add(auto);
    }

    /**
     * Método que muestra los elementos añadidos al ArrayList
     * @return Devuelve los autos que se han añadido a la lista.
     */
    public ArrayList<Auto> listarAutos() {
        return autos;
    }

    /**
     * Método que imprime por pantalla la lista de autos que se han añadido.
     */
    public void imprimirAutos(){
        for (Auto auto: autos){
            System.out.println(auto);
        }
    }
}
